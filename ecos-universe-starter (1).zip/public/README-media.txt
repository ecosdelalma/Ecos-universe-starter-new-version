Place your media files here: /videos/landing.mp4 and /images/landing-fallback.jpg
