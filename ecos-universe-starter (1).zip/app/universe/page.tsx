export default function Universe() {
  return (
    <main className="grid min-h-dvh place-items-center text-white">
      <div className="text-center">
        <h1 className="text-3xl font-semibold tracking-wide">Ecos Universe</h1>
        <p className="mt-2 opacity-80">Bienvenido. Esta es una pantalla placeholder para continuar el flujo.</p>
      </div>
    </main>
  );
}
