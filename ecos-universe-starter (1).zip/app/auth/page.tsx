"use client";
import React, { useState } from "react";
import { supabase } from "@/lib/supabase/client";
import Link from "next/link";

export default function AuthPage() {
  const [email, setEmail] = useState("");
  const [accepted, setAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function signInWithGoogle() {
    try {
      setLoading(true);
      if (!accepted) throw new Error("Debes aceptar Términos y Condiciones.");
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          queryParams: { prompt: "select_account" },
          redirectTo: typeof window !== "undefined" ? `${window.location.origin}/profile` : undefined,
        },
      });
      if (error) throw error;
    } catch (e: any) {
      setMessage(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function signInWithEmail() {
    try {
      setLoading(true);
      if (!accepted) throw new Error("Debes aceptar Términos y Condiciones.");
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: typeof window !== "undefined" ? `${window.location.origin}/profile` : undefined,
          data: {
            accepted_tos: true,
            accepted_tos_version: "1.0",
            accepted_tos_at: new Date().toISOString(),
          },
        },
      });
      if (error) throw error;
      setMessage("Te envié un enlace de acceso. Revisa tu correo.");
    } catch (e: any) {
      setMessage(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="relative min-h-dvh w-dvw text-white">
      <video className="fixed inset-0 h-full w-full object-cover" src="/videos/landing.mp4" autoPlay loop muted playsInline />
      <div className="fixed inset-0 bg-black/50" />

      <div className="relative z-10 mx-auto flex max-w-md flex-col gap-6 px-6 py-16">
        <h1 className="text-center text-2xl font-semibold tracking-wide">[ be ecos ]</h1>
        <p className="text-center text-sm opacity-80">Entra con tu cuenta o recibe un enlace por correo.</p>

        <label className="flex items-start gap-3 text-sm">
          <input type="checkbox" className="mt-1 h-4 w-4" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} />
          <span>
            Acepto los <Link href="/legal/terms" className="underline">Términos y Condiciones</Link> y la <Link href="/legal/privacy" className="underline">Política de Privacidad</Link>.
          </span>
        </label>

        <button onClick={signInWithGoogle} disabled={loading} className="rounded-2xl border border-white/60 bg-white/10 px-6 py-3 backdrop-blur-sm transition-all hover:bg-white/20 disabled:opacity-60">
          Continuar con Google
        </button>

        <div className="grid gap-3">
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="tu@email.com"
            className="rounded-xl border border-white/40 bg-transparent px-4 py-3 outline-none placeholder:text-white/60" />
          <button onClick={signInWithEmail} disabled={loading || !email} className="rounded-2xl border border-white/60 bg-white/10 px-6 py-3 backdrop-blur-sm transition-all hover:bg-white/20 disabled:opacity-60">
            Enviarme enlace de acceso
          </button>
        </div>

        {message && <div className="rounded-xl border border-white/30 bg-black/40 p-3 text-sm">{message}</div>}
      </div>
    </main>
  );
}
