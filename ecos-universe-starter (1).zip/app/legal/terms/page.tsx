export default function Terms() {
  return (
    <main className="prose prose-invert mx-auto max-w-3xl px-6 py-12">
      <h1>Términos y Condiciones</h1>
      <p>Versión 1.0 — Placeholder legal. Reemplaza este texto por tus T&C reales.</p>
      <ul>
        <li>Uso personal de la plataforma Ecos Universe</li>
        <li>Privacidad y manejo de datos</li>
        <li>Conducta y contenido permitido</li>
      </ul>
    </main>
  );
}
