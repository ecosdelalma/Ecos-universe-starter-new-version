export default function Privacy() {
  return (
    <main className="prose prose-invert mx-auto max-w-3xl px-6 py-12">
      <h1>Política de Privacidad</h1>
      <p>Placeholder de privacidad. Ajusta a tu realidad y leyes vigentes.</p>
    </main>
  );
}
