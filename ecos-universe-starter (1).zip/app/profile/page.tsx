"use client";
import React, { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function ProfileOnboarding() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [sessionUserId, setSessionUserId] = useState<string | null>(null);
  const [form, setForm] = useState({
    display_name: "",
    alias: "",
    word: "",
    eco_type: "",
    color: "",
    photo_url: "",
    bio: "",
  });
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace("/auth");
        return;
      }
      setSessionUserId(user.id);

      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      if (data) {
        setForm({
          display_name: data.display_name ?? "",
          alias: data.alias ?? "",
          word: data.word ?? "",
          eco_type: data.eco_type ?? "",
          color: data.color ?? "",
          photo_url: data.photo_url ?? "",
          bio: data.bio ?? "",
        });
      }
      setLoading(false);
    })();
  }, [router]);

  async function save() {
    try {
      if (!sessionUserId) return;
      setLoading(true);
      const payload = { ...form, accepted_tos: true, accepted_tos_version: "1.0", accepted_tos_at: new Date().toISOString() };
      const { error } = await supabase.from("profiles").upsert({ id: sessionUserId, ...payload });
      if (error) throw error;
      router.replace("/universe");
    } catch (e: any) {
      setMessage(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="relative min-h-dvh w-dvw text-white">
      <video className="fixed inset-0 h-full w-full object-cover" src="/videos/landing.mp4" autoPlay loop muted playsInline />
      <div className="fixed inset-0 bg-black/60" />

      <div className="relative z-10 mx-auto max-w-2xl px-6 py-12">
        <h1 className="mb-6 text-center text-xl font-semibold tracking-wide">Tu perfil</h1>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {[
            ["display_name", "Nombre o seudónimo"],
            ["alias", "Alias corto (opcional)"],
            ["word", "Palabra que te representa"],
            ["eco_type", "Tipo de eco"],
            ["color", "Color emocional"],
          ].map(([key, label]) => (
            <label key={key} className="grid gap-2">
              <span className="text-sm opacity-80">{label}</span>
              <input
                className="rounded-xl border border-white/40 bg-transparent px-4 py-3 outline-none"
                value={form[key as keyof typeof form] as string}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
              />
            </label>
          ))}
        </div>

        <label className="mt-4 grid gap-2">
          <span className="text-sm opacity-80">Breve bio</span>
          <textarea rows={4} className="rounded-xl border border-white/40 bg-transparent px-4 py-3 outline-none"
            value={form.bio} onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))} />
        </label>

        <div className="mt-6 flex items-center gap-3">
          <button onClick={save} disabled={loading} className="rounded-2xl border border-white/60 bg-white/10 px-6 py-3 backdrop-blur-sm transition-all hover:bg-white/20 disabled:opacity-60">
            Guardar y entrar a Ecos
          </button>
          {message && <span className="text-sm opacity-80">{message}</span>}
        </div>
      </div>
    </main>
  );
}
